"""Agent adapters with lazy public imports (gptme is the only backend)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .base import AgentAdapter
    from .gptme_adapter import GptmeAdapter

_LAZY_EXPORTS = {
    "AgentAdapter": ".base",
    "GptmeAdapter": ".gptme_adapter",
}

__all__ = ["AgentAdapter", "GptmeAdapter"]


def __getattr__(name: str) -> Any:
    module_name = _LAZY_EXPORTS.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    from importlib import import_module

    return getattr(import_module(module_name, __name__), name)


def __dir__() -> list[str]:
    return sorted(__all__)