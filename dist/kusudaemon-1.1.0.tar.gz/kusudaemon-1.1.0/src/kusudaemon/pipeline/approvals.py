"""Human-in-the-loop approval records, cross-process (PLAN.md §10, §11).

The driver and its human surfaces (the TUI, CLI ``approve``) never share a
lock or a pipe: every approval is a record in the run directory's
``approvals.jsonl``, append-only, latest record per ``approval_id`` wins.
The driver creates a ``pending`` record and then *polls the file* until a
resolved record for the same id shows up; the TUI and the CLI resolve
by appending that resolved record. Any surface can therefore answer what
any other surface asked, and a crashed driver waits on nothing — resolution
is a durable fact on disk, not a pipe buffer. There is no in-memory
authority: the file IS the authority (``tui/state.py`` reads it fresh on
every poll rather than keeping its own mirror).

Record shape (flat dict, JSON-serializable):

    approval_id: str          -- uuid, unique per checkpoint
    kind: str                 -- "intake_question" | "pilot" | "amend" |
                                 "triage" | "reopen" | "confirm"
    title / message           -- what the operator is being asked
    options: [{value, label, style}]  -- button choices (may be empty)
    allow_input / input_label  -- whether a free-form answer is allowed
    context: dict             -- extensible metadata (phase, node_id, ...)
    status: "pending" | "resolved"
    action: str                -- chosen option value once resolved
    user_input: str            -- free-form answer / edited document once resolved
    reason: str | ""
    created_at / resolved_at: float
    questions: [{id, text}]   -- PLAN.md §A5/§B3: a batch-form approval (e.g.
                                 kind "intake_questions") carries every
                                 question for one round here instead of one
                                 approval per question; empty for every
                                 other kind. Additive, defaulted -- every
                                 pre-§B3 approvals.jsonl line loads unchanged.
    answers: {id: text}       -- the operator's per-question answers once
                                 resolved, keyed by the matching entry in
                                 `questions`. Blank/missing = unanswered.
                                 Additive, defaulted, same reasoning.
"""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .run_dir import approvals_path

_DEFAULT_POLL_INTERVAL = 1.0


@dataclass
class Approval:
    approval_id: str
    kind: str
    title: str
    message: str = ""
    options: list[dict[str, str]] = field(default_factory=list)
    allow_input: bool = True
    input_label: str = ""
    context: dict[str, Any] = field(default_factory=dict)
    status: str = "pending"
    action: str = ""
    user_input: str = ""
    reason: str = ""
    created_at: float = field(default_factory=time.time)
    resolved_at: float | None = None
    questions: list[dict[str, str]] = field(default_factory=list)
    answers: dict[str, str] = field(default_factory=dict)

    def resolve(
        self, *, action: str = "", user_input: str = "", reason: str = "",
        answers: dict[str, str] | None = None,
    ) -> "Approval":
        self.action = str(action or "")
        self.user_input = str(user_input or "")
        self.reason = str(reason or "")
        self.answers = {str(k): str(v) for k, v in (answers or {}).items()}
        self.status = "resolved"
        self.resolved_at = time.time()
        return self

    @staticmethod
    def create(
        kind: str, *, title: str, message: str = "", options: list[dict[str, str]] | None = None,
        allow_input: bool = True, input_label: str = "", context: dict[str, Any] | None = None,
        questions: list[dict[str, str]] | None = None,
    ) -> "Approval":
        return Approval(
            approval_id=uuid.uuid4().hex[:12],
            kind=kind,
            title=title,
            message=message,
            options=list(options or []),
            allow_input=allow_input,
            input_label=input_label,
            context=context or {},
            questions=[dict(q) for q in (questions or [])],
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Approval":
        know = {key: data[key] for key in ("approval_id", "kind", "title") if key in data}
        return Approval(
            **know,
            message=str(data.get("message", "")),
            options=[dict(opt) for opt in list(data.get("options") or [])],
            allow_input=bool(data.get("allow_input", True)),
            input_label=str(data.get("input_label", "")),
            context=dict(data.get("context") or {}),
            status=data.get("status", "pending"),
            action=str(data.get("action", "")),
            user_input=str(data.get("user_input", "")),
            reason=str(data.get("reason", "")),
            created_at=float(data.get("created_at") or time.time()),
            resolved_at=data.get("resolved_at"),
            questions=[dict(q) for q in list(data.get("questions") or [])],
            answers={str(k): str(v) for k, v in dict(data.get("answers") or {}).items()},
        )


def append(run_dir: str | Path, record: dict[str, Any] | Approval) -> None:
    """Persist one record (pending or resolved). The file is the authority.
    fsync per append, like events.jsonl: the record that can be lost here is
    the operator's pilot edit (§11.6), and a power loss or kill -9 must not
    be able to eat it after this returns."""
    payload = record.to_dict() if isinstance(record, Approval) else dict(record)
    path = approvals_path(run_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
        fh.flush()
        os.fsync(fh.fileno())


def read_all(run_dir: str | Path) -> list[Approval]:
    """Latest record per approval_id, in first-seen order."""
    merged: dict[str, Approval] = {}
    order: list[str] = []
    path = approvals_path(run_dir)
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(data, dict) or "approval_id" not in data:
            continue
        approval_id = str(data["approval_id"])
        if approval_id not in merged:
            order.append(approval_id)
        merged[approval_id] = Approval.from_dict(data)
    return [merged[key] for key in order]


def pending(run_dir: str | Path) -> list[Approval]:
    return [item for item in read_all(run_dir) if item.status == "pending"]


def find_pending(run_dir: str | Path, *, kind: str, **context: Any) -> Approval | None:
    """Reuse an unanswered checkpoint for the same (kind, context) pair —
    makes resume re-ask the very question it already asked instead of
    stacking duplicates."""
    for item in pending(run_dir):
        if item.kind != kind:
            continue
        matches = all(item.context.get(key) == value for key, value in context.items())
        if matches:
            return item
    return None


def wait_for_resolution(
    run_dir: str | Path,
    approval_id: str,
    *,
    poll_interval: float = _DEFAULT_POLL_INTERVAL,
    timeout: float | None = None,
) -> Approval:
    """Block the calling (driver) thread until a resolved record for
    ``approval_id`` lands on disk. ``timeout=None`` waits forever — the
    operator is the one control surface that must never be rushed.

    §11.10.12: parses only the bytes appended since the last poll, never
    the whole file again — pilot records embed artifact text, so an
    overnight wait would otherwise be a full JSON parse of the growing log
    every second."""
    scanner = _ApprovalScanner(run_dir)
    deadline = None if timeout is None else time.monotonic() + timeout
    while True:
        for item in scanner.next_records():
            if item.approval_id == approval_id and item.status == "resolved":
                return item
        if deadline is not None and time.monotonic() >= deadline:
            raise TimeoutError(f"approval {approval_id} was not resolved in time")
        time.sleep(poll_interval)


class _ApprovalScanner:
    """Persistent reader over ``approvals.jsonl`` for pollers.

    Remembers the byte offset of the last complete line, so the poll loop
    stores O(new bytes) per tick instead of O(log). The offset advances
    only up to the last ``\\n`` — a torn trailing line (concurrent append)
    is re-read whole next tick rather than consumed half, the same trap
    v0/runner.py's session-id watcher documents (§11.9).
    """

    def __init__(self, run_dir: str | Path) -> None:
        self._path = approvals_path(run_dir)
        self._offset = 0

    def next_records(self) -> list[Approval]:
        try:
            size = self._path.stat().st_size
        except OSError:
            return []
        if size <= self._offset:
            return []
        with self._path.open("rb") as fh:
            fh.seek(self._offset)
            chunk = fh.read()
        if chunk.endswith(b"\n"):
            lines = chunk.split(b"\n")
            consumed = len(chunk)
        else:
            *lines, partial = chunk.split(b"\n")
            consumed = len(chunk) - len(partial)
        self._offset += consumed
        records: list[Approval] = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            if not isinstance(data, dict) or "approval_id" not in data:
                continue
            try:
                records.append(Approval.from_dict(data))
            except (TypeError, ValueError):
                continue
        return records


class Approver:
    """A polling resolver used by tests and by surface-free automation: a
    background thread that answers every pending approval as soon as it
    lands, so a driver run can be scripted end to end while exercising the
    exact same disk protocol the web UI uses."""

    def __init__(
        self,
        run_dir: str | Path,
        *,
        action: str = "answer",
        user_input: str = "",
        answers: dict[str, str] | None = None,
        poll_interval: float = 0.05,
    ) -> None:
        self.run_dir = Path(run_dir)
        self.action = action
        self.user_input = user_input
        # PLAN.md §B3: keyed by question id, for a form-shaped approval
        # (non-empty `questions`) -- a question whose id isn't in here
        # resolves blank, same as a silent operator. Ignored entirely for
        # every non-form kind (pilot, amend, ...), which never sets
        # `questions` in the first place.
        self.answers = dict(answers or {})
        self.poll_interval = poll_interval
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.resolved: list[str] = []

    def __enter__(self) -> "Approver":
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=5)

    def _run(self) -> None:
        seen: set[str] = set()
        while not self._stop.is_set():
            for item in pending(self.run_dir):
                if item.approval_id in seen:
                    continue
                seen.add(item.approval_id)
                self.resolve_one(item.approval_id)
            self._stop.wait(self.poll_interval)

    def resolve_one(self, approval_id: str) -> None:
        pending_record = None
        for item in read_all(self.run_dir):
            if item.approval_id == approval_id:
                pending_record = item
        if pending_record is None:
            return
        if pending_record.status == "resolved":
            return
        self.resolve(pending_record)
        self.resolved.append(approval_id)

    def resolve(self, approval: Approval) -> None:
        per_question = {q["id"]: self.answers.get(q["id"], "") for q in approval.questions}
        record = approval.resolve(
            action=self.action, user_input=self.user_input, answers=per_question
        )
        append(self.run_dir, record)
        self.resolved.append(approval.approval_id)