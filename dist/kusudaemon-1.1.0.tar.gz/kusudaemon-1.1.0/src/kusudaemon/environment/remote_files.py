from __future__ import annotations

import os
import posixpath
import shlex
import tempfile
from pathlib import Path

from .base import Environment
from ..types import DEFAULT_TMP_DIR


async def write_remote_text(env: Environment, remote_path: str, content: str, mode: str = "0644") -> None:
    parent = posixpath.dirname(remote_path.rstrip("/"))
    if parent:
        await ensure_remote_dir(env, parent)

    tmp_path: str | None = None
    try:
        # Prompts can carry task secrets, so stage them in the run's own tmp dir
        # rather than a directory shared by every run on the machine.
        staging = getattr(env, "staging_dir", None)
        tmp_dir = Path(staging) if staging else Path(DEFAULT_TMP_DIR)
        tmp_dir.mkdir(parents=True, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(prefix="kusudaemon_remote_", dir=tmp_dir, text=True)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(content)
        await env.upload(tmp_path, remote_path)
    finally:
        if tmp_path is not None:
            try:
                Path(tmp_path).unlink()
            except OSError:
                # PLAN.md §D7: a bind mount or some network/container mounts
                # can raise PermissionError (or another OSError) here even
                # though this process created the file moments earlier —
                # catching only FileNotFoundError let that escape the
                # cleanup path and fail the whole episode after the prompt
                # had already uploaded successfully. A leaked temp file is
                # cosmetic; a failed episode is not.
                pass

    result = await env.exec(f"chmod {shlex.quote(mode)} {shlex.quote(remote_path)}", timeout=300)
    if result.exit_code != 0:
        raise RuntimeError(f"failed chmod {remote_path}: {result.stderr or result.stdout}")


async def ensure_remote_dir(env: Environment, remote_path: str) -> None:
    result = await env.exec(f"mkdir -p {shlex.quote(remote_path)}", timeout=300)
    if result.exit_code != 0:
        raise RuntimeError(f"failed creating {remote_path}: {result.stderr or result.stdout}")
